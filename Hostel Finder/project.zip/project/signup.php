<?php include('backend/server.php') ?>
<?php include('nav.php'); ?>

<div class="jumbotron">
<div class="container">

<h3 align="center" >REGISTER</h3>
<form autocomplete="off" class="form-horizontal" action="signup.php" method="POST">

  <?php include('backend/error.php'); ?>
  
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">UserName:</label>
      <div class="col-sm-5">
        <input pattern=".{5,100}" required title="Minimum length is 5." type="text" class="form-control" name="username" autocomplete="off" value="<?php echo $username; ?>" >
      </div>
    </div>

     <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Email id:</label>
      <div class="col-sm-5">          
        <input type="email" class="form-control" name="email" value="<?php echo $email; ?>" >
      </div>
    </div>


     <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-5">          
        <input pattern=".{5,100}" required title="Minimum length is 5." type="password" class="form-control" autocomplete="off" name="password_1"  >
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Confirm Password:</label>
      <div class="col-sm-5">          
        <input type="password" class="form-control" name="password_2" >
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="reg_user" class="btn mybtns btnsignup">Sign up</button>
      </div>
    </div>
<h3> Already a member? <a href="loginn.php">Sign in</a> </h3>
  </form>
</div> 
</div>
</div>
</div>
</div>
</body>