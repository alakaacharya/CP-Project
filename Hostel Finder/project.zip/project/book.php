<?php 
include('backend/config.php');
include('backend/db.php');
 ?>

<?php
if(isset($_SESSION['username'])){
  echo "<script type='text/JavaScript'>alert('Welcome!'); </script>";
} ?>

<?php include('nav.php'); ?>

<div class="jumbotron">
<div class="container">
  <h2 align="center" style="color: orange; margin-bottom: 20px;" > Book your seats</h2>

<div class="container">
  <form class="form-horizontal" action="backend/serverbook.php" method="POST">

<!-------------------------INFO-------------->
<div class="container">
  <div class="col-sm-2">
  </div>
    
    <div class="col-sm-7">
<div class="form-group">
  <label for="sel1" >Whom are you booking for?</label>
  <select class="form-control" name="fb_who" id="fb_who">
    <option>Yourself</option>
    <option>Friend</option>
    <option>Child</option>
    <option>Relative</option>
    <option>Other</option>
  </select>
</div>

<?php
  $get_data=mysqli_query($config,"select * from hostels where hostel_id=1");
    while($result_data=mysqli_fetch_assoc($get_data)){
      ?>

<div class="form-group">
  <label for="hostelname"> Hostel Name:</label>
  <select class="form-control" name="fb_hosname" >
    <option>Diyalo</option>
    <option> <?php echo $result_data['hostel_name'];?> </option>
    <option>Motherland</option>
    <option>All Nepal</option>
    <option>Sathi ko ghar</option>
  </select>
<?php } ?>
</div>
</div>
<br/> <br/> <br/><br/>
<h2> Student details</h2>

<div class="col-sm-5">
    <div class="form-group">
      <label for="name"> Name:</label>
      <input type="text" class="form-control" id="bookname" name="fb_name" required>
    </div>

    <div class="form-group">
      <label for="Hostelname">Permanent Address:</label>
      <input type="text" class="form-control" id="peradd" name="fb_add" required>
    </div>

    <div class="form-group">
  <label for="sel1" >Expected time of stay</label>
  <select class="form-control" id="fb_time" name="fb_time" required>
    <option>1-6 months</option>
    <option>upto 1 year</option>
    <option>up to 2 years</option>
    <option>more than 2 years</option>
  </select>
</div>
</div>
    <div class="col-sm-5">
      <div class="form-group">
      <label for="age">Age :</label>
      <input pattern=".{2,2}" required="" title="Too old/young?" type="number" class="form-control" id="age" name="fb_age" >
    </div>
<div class="form-group">
      <label for="name">Phone no :</label>
      <input pattern=".{6,15}" required="Minimum length is 6" title="Minimum 6"  type="Phone"  class="form-control" id="name" name="fb_phone" required>
    </div>

    <div class="form-group">
      <label for="name"> Parents Phone no :</label>
      <input pattern=".{6,15}" required="Minimum length is 6" title="Minimum 6" type="Phone" class="form-control" id="name" name="fb_parent" required>
    </div>
</div> </div>
<hr style="height:1px; border:none; color:red; background-color:#000;">
<input type="submit" name="book_user" class="btn mybtns" value=" Submit">
</form>
</div>
</div>
</div>
</div>
</body>





