<?php
session_start();
if(isset($_SESSION['username'])){
  echo "<script type='text/JavaScript'>alert('Welcome user!'); </script>";
}
?>

<?php
include('nav.php');
?>

<!----------CAROUSELLLLLL -->
<div class="container-fluid">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="media/hd3.jpg" alt="Los Angeles" width="100%" height="50px" >
      </div>

      <div class="item">
        <img src="media/hd1.jpg" alt="Chicago" width="100%" height="50%">
      </div>
    
      <div class="item">
        <img src="media/hd2.jpg" alt="New york" width="100%" height="50%">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!------------------------- --SEARCHHH AREAAAAA  ------------->
  <div class="form-inline searchhere">

<form action="searchtwo.php" method="GET">
      <label for="gensearch"> </label>
      <select class="form-control sel3" name="querygen">
       <option selected disabled>Gender</option>
        <option>Girls</option>
        <option>Boys</option> 
      </select> 

      <label for="locsearch"> </label>
      <select class="form-control sel3" name="queryloc">
      <option selected disabled>Location </option>
        <option>New Baneshwor</option>
        <option>Maitidevi</option>
        <option>Lazimpat</option>
        <option>Maharajgunj</option>
      </select>

<button type="submit" class="btn mybtns">Submit</button>
</form>
</div>

<form action="search.php" method="GET">
<div class="input-group input-group-lg locsearch">
      <input type="text" name="query" class="form-control" placeholder="Search by name..">
      <div class="input-group-btn">
        <button class="btn btn-default" value="search" type="submit"><i class="glyphicon glyphicon-search"></i></button>
      </div>
    </div>
   </form>   
<br/> <br/><br/><br/><br/>

<!---------------------------------FOOTER  ------------------->
<div class="panel-footer">
<hr>
<div class="row">
	<div class="col-sm-3">
  <h4 style="text-align: center;">All hostels in a website?</h4>
  <p>Find all the hostel around the city in the same place. No use to run around to search for hostels.
  Find all the hostel around the city in the same place. No use to run around to search for hostels.
Find all the hostel around the city in the same place. No use to run around to search for hostels.</p>
 </div>
 
 <div class="col-sm-3">
  <h4 style="text-align: center;">Our Team</h4>
  <p>We are a team of 5 developers and close friends hoping to deliver the best services to you
  We are a team of 5 developers and close friends hoping to deliver the best services to you.
We are a team of 5 developers and close friends hoping to deliver the best services to you..</p>
  </div>

<div class="col-sm-3">
  <h4 style="text-align: center;">Get discounts</h4>
  <p>Get discount on booking of hostel while booking via hostel finder.
  Get discount on booking of hostel while booking via hostel finder.
Get discount on booking of hostel while booking via hostel finder.</p>
  </div>

  <div class="col-sm-3">
  <h4 style="text-align: center;">Send us feedbacks </h4>
  <p>Send us your feedbacks and help us improve. Go to the help page to find our suggestion box.
  Send us your feedbacks and help us improve. Go to the help page to find our suggestion box.
Send us your feedbacks and help us improve. Go to the help page to find our suggestion box.</p>
  </div>
</div>

<!---------------------------------FOOTER AREA-------------------->
<div class="container-fluid"> <hr>
<div class="col-sm-5 links">
 <h4> Follow us: </h4> 
 <a class="icon" href="https://www.facebook.com"> <img src="media/facebook.png" height="50px" width="50px"></a> 
<a class="icon" href="https://instagram.com"> <img src="media/insta.png" height="50px" width="50px">  </a> 
 <a class="icon" href="https://twitter.com"> <img src="media/tlogo.png" height="50px" width="50px"> </a> 
</div>
 
<div class="col-sm-5 links">
<h4> Get in touch: </h4> <br>
<ul class="contactlogos">
<li class="icon"> <img src="media/phone.png" height="50px" width="50px"> 98888888  </li> 
<li class="icon"> <img src="media/maillogo.png" height="50px" width="50px"> alaka.acharya@outlook.com </li>
<li class="icon"> <img src="media/viberlogo.png" height="50px" width="50px"> 9802133434  </li>
<li class="icon"> <img src="media/loclogo.png" height="50px" width="50px"> Dillibazar, Kathmandu </li>
</ul>
</div>
</div> <hr>
<p style="text-align: center;">Copyright &copy; 2018,Alaka Acharya | Email:alaka.acharya@outlook.com </p>
</div> 
</div>
</div>
</div>
</body>
</html>
