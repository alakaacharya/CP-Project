
<!------------- FIXEDDDDDDDDDD  AREAAAAA   ------------->
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Hostel Finder</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


<!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
<!-- Latest compiled JavaScript -->
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  <script src="js/stars.js"> </script>
<!---------------- MY CSS  -------->
<link rel="stylesheet" href="../css/demo.css" type="text/css">

</head>

<body>

<div class="container">

 <a href="#" class="navbar-brand"><img src="../media/logo.png" height="80px" width="80px"></a> 

<!------------- NAVIGATION BAR  ------------->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      
 <li><a href="../cpindex.php">Home</a></li>
      <li><a href="../Vacancies.php">Vacancies </a></li>
      <li><a href="../list.php">Hostels </a></li>
      <li><a href="../top10.php">Top 10</a></li>
        <li><a href="../addhostel.php">Add your hostel </a></li>
       <li><a href="../help.php">Help </a></li>
    </ul>
  </div>
</nav>


<!------------- NAVIGATION BAR 2 ------------->
<nav class="navbar navbar-default lognav">
  <div class="container-fluid">
    <ul class="nav navbar-nav">

      <li><a href="<?php if(isset($_SESSION['username'])){
        echo "backend/logout.php";
      }
      else{
      echo "loginn.php";
    }
    ?>">
    <?php if(isset($_SESSION['username'])){
      echo "Logout";
    }else{
      echo "Login";
      } ?> </a>
      <li> <a href="signup.php"> Register </a></li>    
    </ul>
  </div>
</nav>


<div class="container-fluid">
  <h2> Hostel Finder </h2> </div>
<!------------- FIXED AREA ENDSSSS   ------------->