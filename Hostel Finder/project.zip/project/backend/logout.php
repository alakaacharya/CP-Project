<?PHP
session_start();
session_destroy();
header("Location: ../cpindex.php?message=logout");
?>