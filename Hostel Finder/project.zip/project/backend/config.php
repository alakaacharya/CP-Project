<?php
$config = mysqli_connect('localhost','root','') or die('Error');
mysqli_select_db($config, 'dbcp') or die ('wrong');

