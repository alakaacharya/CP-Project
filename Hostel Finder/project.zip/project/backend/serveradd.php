<?php
$mysqli = new mysqli("localhost", "root", "", "dbcp");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
// Escape user inputs for security
$add_on = $mysqli->real_escape_string($_REQUEST['add_on']);
$add_hn = $mysqli->real_escape_string($_REQUEST['add_hn']);
$add_had = $mysqli->real_escape_string($_REQUEST['add_had']);
$add_gmap = $mysqli->real_escape_string($_REQUEST['add_gmap']);

$add_gender = $mysqli->real_escape_string($_REQUEST['optradio']);
$add_service = implode(',', $_REQUEST['servch']);

$add_af = $mysqli->real_escape_string($_REQUEST['add_af']);
$add_sd = $mysqli->real_escape_string($_REQUEST['add_sd']);
$add_p1 = $mysqli->real_escape_string($_REQUEST['add_p1']);
$add_p2 = $mysqli->real_escape_string($_REQUEST['add_p2']);
$add_p3 = $mysqli->real_escape_string($_REQUEST['add_p3']);
$add_p4 = $mysqli->real_escape_string($_REQUEST['add_p4']);

$add_phone = $mysqli->real_escape_string($_REQUEST['add_phone']);
$add_email = $mysqli->real_escape_string($_REQUEST['add_email']);
 
// Insert query
$sql = "INSERT INTO add_hostel (add_on,add_had, add_hn, add_gmap,add_af,add_sd,
 add_p1, add_p2, add_p3, add_p4, add_gender, add_service, add_phone,add_email) 
 VALUES ('$add_on', '$add_hn', '$add_had','$add_gmap','$add_af','$add_sd',
 '$add_p1','$add_p2','$add_p3','$add_p4', '$add_gender', '$add_service', '$add_phone','$add_email')";

if($mysqli->query($sql) === true){
	 echo "<script type='text/JavaScript'>alert('Hostel Added!');
  window.location='../addhostel.php'
   </script>";

} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
 
// Close connection
$mysqli->close();
?>