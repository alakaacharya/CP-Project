<?php
$mysqli = new mysqli("localhost", "root", "", "dbcp");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
// Escape user inputs for security
$hostel_name = $mysqli->real_escape_string($_REQUEST['fb_hosname']);
$book_for = $mysqli->real_escape_string($_REQUEST['fb_who']);
$book_name = $mysqli->real_escape_string($_REQUEST['fb_name']);
$book_pa = $mysqli->real_escape_string($_REQUEST['fb_add']);
$book_age = $mysqli->real_escape_string($_REQUEST['fb_age']);
$book_phone = $mysqli->real_escape_string($_REQUEST['fb_phone']);
$book_time = $mysqli->real_escape_string($_REQUEST['fb_time']);
$book_parent = $mysqli->real_escape_string($_REQUEST['fb_parent']);
 
//  insert query 
$sql = "INSERT INTO book (hostel_name,book_for, book_name, book_pa,book_age,book_phone, book_time, book_parent)
 VALUES ('$hostel_name', '$book_for', '$book_name','$book_pa','$book_age','$book_phone','$book_time','$book_parent')";
if($mysqli->query($sql) === true){

  echo "<script type='text/JavaScript'>alert('Booked!');
  window.location='../book.php'
   </script>";

} else{
    echo "ERROR: Error! Couldn't execute SQL! " . $mysqli->error;
}
 
// Close connection
$mysqli->close();
?>