<?php include('backend/server.php') ?>
<?php include('nav.php'); ?>

<div class="jumbotron">
<div class="container">

  <h3 align="center" >LOGIN</h3>
<form  autocomplete="off" class="form-horizontal" method="post" action="loginn.php">
  <?php include('backend/error.php'); ?>
    <div class="form-group">
      <label class="control-label col-sm-2" for="username">UserName:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" name=username id="email" placeholder="Enter email">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-5">          
        <input type="password" class="form-control" autocomplete="off" name="password" id="pwd" placeholder="Enter password">
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-5">
        <div class="checkbox">
          <label><input type="checkbox"> Remember me</label>
        </div>
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="login_user" class="btn mybtns">Submit</button>
      </div>
    </div>

   <h3>  Don't have an account?  <a href="signup.php"> Click Here </a> to register! </h3>
  </form>
</div> 
</div>
</div>
</div>
</div>
</body>