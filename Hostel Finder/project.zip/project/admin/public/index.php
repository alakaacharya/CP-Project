<?php
session_start();
if(isset($_SESSION['username'])){
}
?>


<!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
<!-- Latest compiled JavaScript -->
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
 <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!---------------- MY CSS  -------->
<link rel="stylesheet" href="css/styletab.css" type="text/css">
<!----------------------------- FONT AWESOME ------ ---------->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

 <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">

<body>

<nav class="navbar navbar-default lognav">
  <div class="container-fluid">
    <ul class="nav navbar-nav">

      <li><a href="<?php if(isset($_SESSION['username'])){
        echo "../../backend/logout.php";
      }
      else{
      echo "loginn.php";
    }
    ?>">
    <?php if(isset($_SESSION['username'])){
      echo "Logout";
    }else{
      echo "Login";
      } ?> </a>
 
    </ul>
  </div>
</nav>

<h4>
<ul>
	<li><a href="update.php"><strong>Update</strong></a> - Edit a user</li> <br>
	<li><a href="delete.php"><strong>Delete</strong></a> - Delete a user</li>
</ul>
</h4>

</body>

