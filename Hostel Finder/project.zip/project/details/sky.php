<?php 
include('../backend/config.php');
include('../backend/db.php');
 ?>
<?php
session_start();
if(isset($_SESSION['username'])){
}
?>

<?php 
include('../navtwo.php');
?>

<?php
  $get_data=mysqli_query($config,"select * from hostels where hostel_id=5");
    while($result_data=mysqli_fetch_assoc($get_data)){
      ?>

<div class="firstrow"><h3 class="hostelname" style="color: orange; margin-left: 420px;"> <?php echo $result_data['hostel_name'];?> </h3>   </div>

<!------------- IMAGESS IN SLIDEE    ------------->
<div class="hostelimages" align="center" >
          <img class="slides" src="../media/h9.jpg" height="300px" width="60%">
          <img class="slides" src="../media/h10.jpg" height="300px" width="60%">
          <img class="slides" src="../media/h8.jpg" height="300px" width="60%">
          <script type="text/javascript" src="../js/slide.js"></script>
</div>
 

<!------------- DETAILSSSS     ------------->
<div class=" container hosteldetails">


      <div>
   <h4 style="text-decoration: underline;"> General </h4>   
   <ul class="detailslist">  
   <li> Name: <?php echo $result_data['hostel_name'];?> </li> 
  <li> Address: <?php echo $result_data['hostel_address'];?> </li> 
  <li> Phone no: <?php echo $result_data['hostel_phone'];?> </li> 
 <li> Email: <?php echo $result_data['hostel_email'];?> </li>
 <li> Gender: <?php echo $result_data['hostel_gender'];?> </li>
 <li> Owner: <?php echo $result_data['hostel_owner'];?> </li>
</ul>
<h4 style="text-decoration: underline;"> Price per month </h4>  
   <ul class="detailslist">  
   <li> Admission fee: <?php echo $result_data['hostel_af'];?> </li> 
  <li> Security deposit: <?php echo $result_data['hostel_sd'];?> </li> 
  <li> Single bed: <?php echo $result_data['hostel_p1'];?> </li> 
 <li> Double bed: <?php echo $result_data['hostel_p2'];?> </li>
 <li> Triple bed: <?php echo $result_data['hostel_p3'];?> </li>
 <li> Four bed : <?php echo $result_data['hostel_p4'];?> </li>
</ul>

<h4 style="text-decoration: underline;"> Facilities </h4>  
   <ul class="detailslist">  
   <li> Facilities: <?php echo $result_data['hostel_facilities'];?> </li> 
</ul>
</div>


</div>



 <hr style="height:1px; border:none; color:#000; background-color:#000;">


 <!----------------- GOOOGLE MAAAPPP --------------------->
 <div class="maps">
 <div class="col-sm-8">
<div class="google-map"> 
  <h4> View on map: </h4>
        <iframe src="http://bit.ly/softwaricamap" width="30%" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
    </div>

       <!----------------- CONTACT THIS HOSTEL --------------------->
    
    <div class="col-sm-2 hostlinks">
 <h4> Follow this hostel: </h4> 
 <ul class="contactlogos">
 <li> <a class="icon" href="https://www.facebook.com"> <img src="../media/facebook.png" height="50px" width="50px">  </a>  </li>
<li> <a class="icon" href="https://www.instagram.com"> <img src="../media/insta.png" height="50px" width="50px">  </a> </li>
 <li> <a class="icon" href="https://www.twitter.com"> <img src="../media/tlogo.png" height="50px" width="50px"> </a> </li>
</div>
</ul>
</div>

  <li> <?php $result_data['hostel_map'];?> </li>
<?php } ?>
</body>

