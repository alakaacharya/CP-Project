<?php
session_start();
if(isset($_SESSION['username'])){
}
?>
<?php
include('nav.php');
?>
<div class="container">

 <div class="vacbox">
  <div class="pic">
   <img src="media/h9.jpg" alt="hosel" width="250" height="200">
   <h3 class="hosteltitle" $id=1> All Nepal Girls Hostel  </h3>
  </div>  
   <div class="loc">
     <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;">  </i> Lazimpat
     <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
   </div>
    <div class="viewdetails">  <a style="color: white;" href="details/allnepal.php"> View Details </a> </div>         
    <div class="viewdetails">  <a style="color: white;" href="book.php"> Book </a> </div>                          
</div> 

<div class="vacbox">
  <div class="pic">
   <img src="media/h8.jpg" alt="hosel" width="250" height="200">
   <h3 class="hosteltitle" $id=1> Sathi ko ghar  </h3>
  </div>  
   <div class="loc">
     <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;">  </i> New Baneshwor
     <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Boys
   </div>
    <div class="viewdetails">  <a style="color: white;" href="details/sathi.php"> View Details </a> </div>         
    <div class="viewdetails">  <a style="color: white;" href="book.php"> Book </a> </div>                          
</div> 

</div>
</div>
