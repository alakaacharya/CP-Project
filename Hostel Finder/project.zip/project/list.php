<?php
session_start();
if(isset($_SESSION['username'])){
}
?>

<?php
include('nav.php');
?>

<div class="container">

 <div class="hostelbox" id='1'>
  <div class="pic">
   <img src="media/h1.jpg" alt="hosel" width="250" height="200">
   <h3 class="hosteltitle"> All Nepal Girls Hostel  </h3>
  </div>  
   <div class="loc">
     <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;">  </i> Lazimpat
     <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
   </div>
    <div class="viewdetails">  <a style="color: white;" href="details/allnepal.php" > View Details </a> </div>                                
</div> 



<div class="hostelbox" id='2'>
  <div class="pic"> <img src="media/h3.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle" $id="2"> Sathi ko ghar </h3> 
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> New baneshwor
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Boys
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/sathi.php" ?id=$row['2']> View Details </a> </div>
</div>



<div class="hostelbox">
  <div class="pic"> <img src="media/h4.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle"> Diyalo Girls Home </h3>
  </div>
  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> Maharajgunj
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/diyalo.php" ?id=$row['3']> View Details </a> </div>
</div>


<div class="hostelbox">
  <div class="pic"> <img src="media/h5.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle" > Motherland girls Hostel </h3>
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> New Baneshwor
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/motherland.php" ?id=$row['4']> View Details </a> </div>
</div>
  
<div class="hostelbox">
  <div class="pic"> <img src="media/h6.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle"> Sky high boys Hostel </h3>
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> Maharajgunj
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/Sky.php"> View Details </a> </div>
</div>

<div class="hostelbox">
  <div class="pic"> <img src="media/h7.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle"> Mustang Brother's Home </h3>
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> Maitidevi
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Boys
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/Mustang.php" ?id=$row['5'] > View Details </a> </div>
</div>

<div class="hostelbox">
  <div class="pic"> <img src="media/h8.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle"> Green's Inn </h3>
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> Lazimpat
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Boys
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details/greens.php"> View Details </a> </div>
</div>



<div class="hostelbox">
  <div class="pic"> <img src="media/h2.jpg" alt="hostel" width="250" height="200">
    <h3 class="hosteltitle"> Fairy Tale Hostel </h3>
  </div>

  <div class="loc"> <i class="fas fa-map-marker-alt" style="font-size: 25px; color: orange;"></i> Maitidevi
    <i class="fas fa-user" style="font-size: 25px; color: orange;" >  </i> Girls
  </div>
  <div class="viewdetails">  <a style="color: white;" href="details.php" ?id=$row['5'] > View Details </a> </div>
</div>



</div>
</div>
</div>
</body>
</html>

