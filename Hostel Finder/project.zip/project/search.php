<?php
$config = mysqli_connect('localhost','root','') or die('Error');
mysqli_select_db($config, 'dbcp') or die ('wrong');  
?>

<?php
    $query = $_GET['query']; 
    // gets value sent over search form
    $min_length = 3;
    if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $raw_results = mysqli_query($config, "SELECT * FROM hostels WHERE (`hostel_name` LIKE '%".$query."%') OR (`hostel_gender` LIKE '%".$query."%')") or die(mysqli_error());
         
        if(mysqli_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
            while($results = mysqli_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
             
             echo "<p ><h3>".$results['hostel_name']."</h3>".$results['hostel_address']." </br> ".$results['hostel_gender']. "</p> <hr/>" ;
            }   
        }
        else{ // if there is no matching rows do following
            echo "No results";
        }
         
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }
?>