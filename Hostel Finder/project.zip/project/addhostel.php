<?php 
include('backend/config.php');
include('backend/db.php');
 ?>

<?php
session_start();
if(isset($_SESSION['username'])){ 
}
?>
<?php include('nav.php'); ?>

<div class="jumbotron">
<div class="container">
<h2 align="center" style="color: orange; margin-bottom: 20px;" >ADD YOUR HOSTEL DETAILS</h2>

<div class="container">
  <form class="form-horizontal" action="backend/serveradd.php" method="POST">


<!-------------------------INFO -------------->
<div class="container">
<div class="col-sm-5">
    <div class="form-group">
      <label for="name">Owner name:</label>
      <input type="text" class="form-control" id="name" name="add_on" required>
    </div>

    <div class="form-group">
      <label for="Hostelname">Hostel name:</label>
      <input type="text" class="form-control" id="pwd" name="add_hn" required>
    </div>

  <label for="Hostelname">Hostel type:</label> <br>
<label class="radio-inline"><input type="radio" name="optradio"  value="Boys" checked> Boys </label>
<label class="radio-inline"><input type="radio" name="optradio" value="Girls"> Girls </label>     
</div>

<div class="col-sm-5">
     <div class="form-group">
      <label for="Hostelname">Hostel address:</label>
      <input type="text" class="form-control" id="pwd" name="add_had" required>
    </div>

    <div class="form-group">
      <label for="name">Gmap link:</label>
      <input type="name" class="form-control" id="name" name="add_gmap">
    </div>
</div>
</div>
<hr style="height:1px; border:none; color:red; background-color:#000;">

<!-----------------------SERVICES-------------------------->
<div class="container servicecheck">
    <h3> Tick to specify the servies you provide </h3>
 <div class="checkbox">
  <div class="col-sm-5">
      <input type="checkbox" name="servch[]" value="Wi-fi"> Wi-fi <br>
     <input type="checkbox" name="servch[]" value="Security"> Security  <br>
      <input type="checkbox" name="servch[]" value="Healthy food"> Healthy food <br>
      <input type="checkbox" name="servc[]h" value="electricity"> 24-7 electricity  <br>
    </div>

    <div class="col-sm-5">
      <input type="checkbox" name="servch[]" value="Peaceful environment"> Peaceful environment <br>
      <input type="checkbox" name="servch[]" value="Laundry"> Laundry <br>
      <input type="checkbox" name="servch[]" value="hot and cold water"> Hot and cold water 24-7 <br>
      <input type="checkbox" name="servch[]" value="garden"> Garden <br>
      <input type="checkbox" name="servch[]" value="Television"> Television <br>
    </div>
     </div>
   </div>
    <hr style="height:1px; border:none; color:#000; background-color:#000;">
<!--------------------------PRICE-------------------------->
<div class="container">
    <h3> Prices per month </h3>
    <div class="col-sm-5">
    <div class="form-group">
      <label for="fee">Admission fee:</label>
      <input type="number" class="form-control" id="fee" name="add_af">
    </div>

    <div class="form-group">
      <label for="fee">Single bed:</label>
      <input type="number" class="form-control" id="fee" name="add_p1">
    </div>

    <div class="form-group">
      <label for="fee">Three bed:</label>
      <input type="number" class="form-control" id="fee" name="add_p3">
    </div>
  </div>

<div class="col-sm-5">
    <div class="form-group">
      <label for="Hostelname">Security deposit</label>
      <input type="number" class="form-control" id="fee" name="add_sd" >
    </div>

     <div class="form-group">
      <label for="fee">Double bed:</label>
      <input type="number" class="form-control" id="fee" name="add_p2">
    </div>
 

     <div class="form-group">
      <label for="fee">Four bed:</label>
      <input type="number" class="form-control" id="fee" name="add_p4">
    </div>
  </div>
  </div>
  <hr style="height:1px; border:none; color:#000; background-color:#000;">

  <!--------------------------CONTACT DETAILS-------------------------->
 <h3> Contact details  </h3>
 <div class="container">
 <div class="col-sm-5">
    <div class="form-group">
      <label for="name">Phone number:</label>
      <input pattern=".{6,100}" required title="Minimum length is 6." type="phone" class="form-control" id="phone" name="add_phone">
    </div>
    <div class="form-group">
      <label for="Hostelname">Email id:</label>
      <input type="email" class="form-control" id="email" name="add_email">
    </div>
  </div>
</div>
<input type="submit" name="add_hostel" class="btn mybtns" value="Submit">
</form>
</div>
</div>
</div>
</div>
</body>





