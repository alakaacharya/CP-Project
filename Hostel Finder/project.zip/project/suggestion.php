<?php
session_start();
if(!isset($_SESSION['username'])){
  header("Location:cpindex.php?messagae=something went wrong");
}

include('backend/db.php');
  $sqlget= "SELECT * FROM community";
  $result=mysqli_query($conn, $sqlget);
  if (!$result) {
    echo "query error";
  }
?>

<?php
  if (isset($_POST['submit'])) {
    $active_user=$_SESSION['username'];
    $comment=$_POST['new_comment'];
    $sqlget= "INSERT INTO community(name,comment)values('$active_user', '$comment')";
    $result=mysqli_query($conn, $sqlget);
    if (!$result) {
      echo "query error<br>";
      echo $sqlget;
    }
    else{
      header("Location: suggestion.php?message=Comment added");
    }
  }
?>

<?php include('nav.php'); ?>

<!----------------------- FORM ----------------------->
        <div class="community-body"> <h3> Drop your reviews here!</h3>
        <?php 
          include('backend/db.php');
          $sqlget= "SELECT * FROM community";
          $result=mysqli_query($conn, $sqlget);
          if (!$result) {
            echo "query error";
          }
        ?>
          <?php
            while ($row=mysqli_fetch_assoc($result)){ ?>
              <div class="comment">
                <h4><?php echo $row['name']?></h4>
                <p>
                  <?php echo $row['comment']?>
                </p>
              </div>
              <hr>

            <?php
              }
          ?>
          <form action="suggestion.php" method="POST" class="community-form">
            <textarea placeholder="Your Queries" cols="100" rows="5" name="new_comment"></textarea>
            <input type="submit" name="submit" value="Post">
          </form>   
        </div>
      </div>
