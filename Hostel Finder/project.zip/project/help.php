<?php
session_start();
if(isset($_SESSION['username'])){
}
?>
<?php
include('nav.php');
?>
 <body>
<h4> Hello! Got a minute? Please  <a href="suggestion.php"> Leave us a review here (Login first) </a>  to encourage us! </h4>

<h3 style="color: orange;"> FAQ </h3>
<pre>

• What does the hostel finder do?
-Hostel Finder helps you in finding the right hostel for you!

• What can I do via hostel finder?
-You can search hostels in preferred locations, you can browse through the lists of hostels,
 and you can find the right hostel for you and book it!

• I am a hostel owner. How can I add my hostel in hostel finder?
-You can go to the hostel finder, fill the form with all the details for your hostels and submit it to us.
 We will contact you in few days for verification and your hostel will be added.

• What type of hostels are featured in hostel finder?
-Every boys and girls hostel in Kathmandu valley are featured in hostel finder.

• Can I search for hostels outside Kathmandu valley via hostel finder?
-We are sorry to say that for now, we are featuring the hostels within Kathmandu valley only. We are working towards expanding hostel finder.

• How can I book a hostel?
-Go to the booking form, fill out the details and submit it. Easy!

• What happens once I submit the book form?
-We will forward your details to the respective hostel owners and they will contact you as soon as possible.

• How do I announce vacancy in my hostel?
-Contact us and we will do that for you!

• How can I contact you?
-Go to the contacts page at the footer of homepage for our contact details.
</pre>

<pre>
  <h4> Download user manual <a href="usermanual.pdf">usermanual.pdf</a> </h4> 
  <h3>Registration  </h3>
Registration can be done in few simple steps.
• Visit Register option
 <img src="um/reg1.png" style="margin-left: 100px;" alt="registration" height="400" width="700">

• Fill out the form
  <img src="um/reg2.png" style="margin-left: 100px;" alt="registration" height="250" width="450">
• Submit it
  <img src="um/reg4.png" style="margin-left: 100px;" alt="registration" height="200" width="400">

 <h3>Logging In </h3>
If you have already registered, follow the following steps
• Go to login page
  <img src="um/login.png" style="margin-left: 100px;" alt="registration" height="300" width="500">

• Enter your username and password
  <img src="um/login1.png" style="margin-left: 100px;" alt="registration" height="300" width="500">

• Submit it
 <img src="um/login2.png" style="margin-left: 100px;" alt="registration" height="200" width="400">
 
 <h3> Adding your hostel </h3>
If you are a hostel owner, and you want to add your hostel to our page, follow these steps:
• Go to ‘Add your hostel option’
• A form opens
 <img src="um/addhost.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
  <img src="um/addhost2.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
  
• Fill the form as asked
 <img src="um/addhost3.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
  <img src="um/addhost4.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
• Submit it

After we receive the data, we will contact you as soon as possible to verify the details before publishing it to the page.
Searching
Searching a hostel is very easy with hostel finder. Our search areas are located right at the center of our home page.
 
• Choose the type of hostel you are searching for and your preferred location
• Click on Submit button
  <img src="um/search.png" style="margin-left: 100px;" alt="registration" height="300" width="700">

• All the results will be displayed to you.
 <img src="um/search2.png" style="margin-left: 100px;" alt="registration" height="300" width="700">

This feature is for you if you already know the name of a hostel you want to search.
• Go to the text bar and type a name.
• Click on ‘find icon’
 <img src="um/search3.png" style="margin-left: 100px;" alt="registration" height="150" width="300">
 All the results will be displayed.
 <img src="um/search4.png" style="margin-left: 100px;" alt="registration" height="300" width="700">
<h3> Booking </h3>
To book a hostel, you have to follow the following steps:
• Go to the ‘vacancies’ page to search for vacant hostels.
 <img src="um/book.png" style="margin-left: 100px;" alt="registration" height="380" width="700">

• Find a hostel and click on ‘Book’
• A form opens
 <img src="um/book2.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
 
• Fill the details as specified
 <img src="um/book3.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
• Click on submit form.
• Wait for success message
  <img src="um/book4.png" style="margin-left: 100px;" alt="registration" height="200" width="400">
 
<h3> Leave us a review </h3>
Before you leave, please provide us some feedbacks.
• Visit our help page
• Go to the review form
  <img src="um/rev1.png" style="margin-left: 100px;" alt="registration" height="400" width="700">
• Enter your feedbacks
  <img src="um/rev2.png" style="margin-left: 100px;" alt="registration" height="250" width="500">
• Click on submit button
• Your feedbacks will be then displayed
 <img src="um/rev3.png" style="margin-left: 100px;" alt="registration" height="300" width="500">
</pre>
</body>
